using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WEB_253551_URBANOVICH.UI.Areas.Admin.Pages;

public class IndexModel : PageModel
{
    public void OnGet() { }
}
