namespace WEB_253551_URBANOVICH.UI.Models;

public class KeycloakData
{
    public string Host { get; set; } = string.Empty;
    public string Realm { get; set; } = string.Empty;
    public string ClientId { get; set; } = string.Empty;
    public string ClientSecret { get; set; } = string.Empty;
}
