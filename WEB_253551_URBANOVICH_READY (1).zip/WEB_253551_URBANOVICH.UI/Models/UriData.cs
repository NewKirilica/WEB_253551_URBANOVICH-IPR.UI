namespace WEB_253551_URBANOVICH.UI.Models;

public class UriData
{
    public string ApiUri { get; set; } = "https://localhost:7002/api/";
}
