namespace WEB_253551_URBANOVICH.API.Models;

internal class AuthServerData
{
    public string Host { get; set; } = string.Empty;
    public string Realm { get; set; } = string.Empty;
}
